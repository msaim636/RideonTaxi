# CHANGELOG

## [Unreleased]

## 5.5.0 - 2026-07-23

* Added support for Guzzle 8

## 5.4.0 - 2026-07-18

* Dropped support for PHP <8.3
* Changed the verifier key cache to store key values instead of `Keys` objects

## 5.3.0 - 2025-09-12

* Added support for PHP 8.5

## 5.2.1 - 2024-12-20

* Fixed deprecated implicit nullable parameter

## 5.2.0 - 2024-08-17

* Added support for PHP 8.4
  ([#61](https://github.com/beste/firebase-tokens-php/pull/61))

## 5.1.0 - 2024-05-10

* Restored support for PHP 8.1
* Fixed missing signature check when in non-emulated environments
  ([#56](https://github.com/beste/firebase-tokens-php/pull/56))

## 5.0.1 - 2023-11-29

* Fixed ID Token verification when run in emulated environments.

## 5.0.0 - 2023-11-25

* Added support for PHP 8.3, removed support for PHP 8.1
