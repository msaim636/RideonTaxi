# SECURITY POLICY

## Supported Versions

After each new major release, the previous release will be supported for no
less than 24 months, unless explicitly stated otherwise. This may mean that
there are multiple supported versions at any given time.

## Reporting a Vulnerability

If you discover a security vulnerability within this package, please send an
email to security@gjcampbell.co.uk. All security vulnerabilities will be
promptly addressed. Please do not disclose security-related issues publicly
until a fix has been announced.
